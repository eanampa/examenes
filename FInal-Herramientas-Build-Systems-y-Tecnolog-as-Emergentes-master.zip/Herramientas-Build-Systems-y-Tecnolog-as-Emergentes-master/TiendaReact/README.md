Para poder probar esta version primero deben abrir mongod y ejecutar los siguientes scripts:

1. node server/iniciarData.js
3. npm run dist
4. node servernode.js

El usuario inicial es:
User: user1@tiendanextu.com
password: Cl@veUser1
